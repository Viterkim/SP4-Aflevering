package exercise;

import static com.jayway.restassured.RestAssured.given;

public class Fetcher implements JokeFetcherInterface
{

  private JokeFetcher jokeFetcher;

    public Fetcher(JokeFetcher jokeFetcher)
    {
        this.jokeFetcher = jokeFetcher;
    }

    @Override
    public Joke fetchJokeInternal() throws CommunicationException
    {
        return jokeFetcher.fetchJokeInternal();
    }
  
    /**
     * Fetch a Chuck Norris Joke from http://api.icndb.com
     * @return A new Chuck Norris Joke
     * @throws CommunicationException In case of an error with the external call. 
     *                                This will also send an email to admin
     */
    public Joke fetchJoke() throws CommunicationException {
      try {
        return fetchJokeInternal();
      } catch (CommunicationException e) {
         jokeFetcher.sendEmailInternal("There is a problem with the server: http://api.icndb.com/jokes/random");
         throw e; //Rethrow to signal error to the caller
      }
    }
  
    //DO NOT TEST THIS METHOD: It's just meant as a quick manual test, to see the code in action
    public static void main(String[] args) throws CommunicationException {
      Fetcher f = new Fetcher(new JokeFetcher());
      System.out.println(f.fetchJoke().getJoke());
    }

    @Override
    public String sendEmailInternal(String text)
    {
        return jokeFetcher.sendEmailInternal(text);
    }


}
