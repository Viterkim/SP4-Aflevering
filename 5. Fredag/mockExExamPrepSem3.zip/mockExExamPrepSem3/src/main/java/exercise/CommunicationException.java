package exercise;


public class CommunicationException extends Exception 
{
    
}
