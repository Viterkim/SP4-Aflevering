
package exercise;


public interface JokeFetcherInterface
{
    public Joke fetchJokeInternal() throws CommunicationException;
    public String sendEmailInternal(String text);
}
