
package exercise;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.mockito.Mockito;
import static org.mockito.Mockito.when;


public class FetcherTest
{
    
    public FetcherTest()
    {
    }
    
    @BeforeClass
    public static void setUpClass()
    {
    }
    
    @AfterClass
    public static void tearDownClass()
    {
    }
    
    @Before
    public void setUp()
    {
    }
    
    @After
    public void tearDown()
    {
    }

    @Test
    public void testFetchJokeNormal()throws Exception
    {
        System.out.println("fetchJokeNormal");
        JokeFetcher jf = new JokeFetcher();
        Fetcher instance = new Fetcher(jf);
        String result = instance.fetchJoke().getJoke();
        assertNotNull(result);
    }
    /**
     * Test of fetchJoke method, of class Fetcher.
     */
    @Test
    public void mockedTestFetchJoke() throws Exception
    {
        System.out.println("mockFetchJoke");
        JokeFetcher jf = Mockito.mock(JokeFetcher.class);
        when(jf.fetchJokeInternal()).thenReturn(new Joke("Mocked joke", "From mockito"));
        Fetcher instance = new Fetcher(jf);
        String expResult = "Mocked joke";
        String result = instance.fetchJoke().getJoke();
        assertEquals(expResult, result);
    }
    
    @Test(expected = CommunicationException.class)
    public void mockedFailedTestFetchJoke()throws Exception
    {
        System.out.println("mockFailJoke");
        JokeFetcher jf = Mockito.mock(JokeFetcher.class);
        when(jf.fetchJokeInternal()).thenThrow(CommunicationException.class);
        Fetcher instance = new Fetcher(jf);
        //String returned when email failed
        String expResult = "There is a problem with the server: http://api.icndb.com/jokes/random";
        when(jf.fetchJokeInternal()).thenReturn(new Joke("Mocked joke", "From mockito"));
        String joke = jf.fetchJokeInternal().getJoke();
        assertEquals(jf.sendEmailInternal(joke), expResult);
    }
}
