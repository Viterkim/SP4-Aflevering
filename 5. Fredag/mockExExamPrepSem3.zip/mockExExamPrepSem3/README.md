# mockExExamPrepSem3

Start code for a test exercise given at: [AP degree in computer Science](https://www.cphbusiness.dk/english/study-programmes/ap-degree/computer-science/) 
